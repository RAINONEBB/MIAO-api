from transformers import AutoModelForCausalLM, AutoTokenizer

class AICharacter:
    def __init__(self, name):
        self.name = name
        self.model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-medium")
        self.tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-medium")

    def interact(self, user_input):
        inputs = self.tokenizer.encode(user_input + self.name, return_tensors="pt")
        response_ids = self.model.generate(inputs, max_length=100)
        response = self.tokenizer.decode(response_ids[0], skip_special_tokens=True)
        return response

npc = AICharacter("MIAO-001")
print(npc.interact("你好，MIAO-001！"))
